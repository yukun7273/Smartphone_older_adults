import math

import pandas as pd
import os

# 对23个被试的数据进行拼接
# TDpath = ["tap_original","tap_adjust","drag_original","drag_adjust"]
# pwd = "data2\\"
# # for file in TDpath:
# file = TDpath[0]
# path = pwd + file
# files = os.listdir(path)
# csv_list = []
# for f in files:
#     if os.path.splitext(f)[1] == '.csv':
#         csv_list.append(path + '\\' + f)
#     else:
#         pass
# print(csv_list)
# df = pd.read_csv(csv_list[0], low_memory=False)
# for i in range(1, len(csv_list)):
#     df_i = pd.read_csv(csv_list[i], low_memory=False)
#     pieces = [df[:], df_i[:]]
#     print(df.shape)
#     df = pd.concat(pieces, axis=1).drop_duplicates()
# # df = df.iloc[:, [1, 6, 7]]  #想保留的列的编号。0为起点
# df.to_csv(pwd + "\\aaa\\" + file + '.csv', index=None, encoding='gbk')
#
#
# # 去除同名列
# import pandas as pd
#
# TDpath = ["tap_original","tap_adjust","drag_original","drag_adjust"]
# pwd = "data2\\dealdata\\"
# file = TDpath[0]
# df = pd.read_csv(pwd + file + '.csv')
# print(df.shape)
# df = df.T.drop_duplicates().T
# # print(df.columns.T.drop_duplicates())
# print(df.shape)
# df.to_csv("data2\\dealdata\\quchong_" + file + ".csv", index=None, encoding='gbk')




# 排除tap 异常值
import pandas as pd

TDpath = ["tap_original", "tap_adjust", "drag_original", "drag_adjust"]

pwd = "atemp\\quchongtap_original.csv"

df = pd.read_csv(pwd, header=None)
print(df)
list = df.values.tolist()


# train_data = np.array(df)#np.ndarray()
# list =train_data.tolist()#list


print(list)
print(len(list), len(list[0]))
print(len(list[0]))

for i in range(len(list)):
    for j in range(22):
        if list[i][j] > list[i][28] or list[i][j] < list[i][27]:
            list[i][j] = 0

print(list)
test=pd.DataFrame(data=list)   #数据有三列，列名分别为one,two,three
print(test)
test.to_csv("atemp\\quchongtap_original002.csv", encoding='gbk')



# 用来剔除drag中不成功的操作

import pandas as pd
import numpy as np
import pandas as pd

TDpath = ["tap_original", "tap_adjust", "drag_original", "drag_adjust"]

pwd = "atemp\\quchongtap_original.csv"

df = pd.read_csv(pwd, header=None)
print(df)
list = df.values.tolist()


train_data = np.array(df)#np.ndarray()
list =train_data.tolist()#list


print(len(list), len(list[0]))
print(len(list[0]))

for i in range(len(list)):
    for j in range(len(list[0])):
        if list[i][j] == 0:
            list[i][j + 1] = 11
            list[i][j + 2] = 11


test=pd.DataFrame(data=list)   #数据有三列，列名分别为one,two,three
print(test)
test.to_csv("atemp\\quchongtap_original002.csv", encoding='gbk')


# 根据xys算D

import pandas as pd
import numpy as np
import pandas as pd

TDpath = ["tap_original", "tap_adjust", "drag_original", "drag_adjust"]

pwd = "atemp\\quchongtap_original.csv"

df = pd.read_csv(pwd, header=None)
print(df)
list = df.values.tolist()


train_data = np.array(df)#np.ndarray()
list =train_data.tolist()#list


print(len(list), len(list[0]))
print(len(list[0]))

for i in range(len(list)):
    if i > 0:
        for j in range(len(list[0])):
            if (j+1) % 5 == 3:
                a=  math.sqrt(math.pow(list[i][j-2] - list[i-1][j-2], 2) + math.pow(list[i][j-1] - list[i-1][j-1], 2))
                print(i, j)
                print(list[i][j])
                list[i][j] = a


test=pd.DataFrame(data=list)   #数据有三列，列名分别为one,two,three
print(test)
test.to_csv("atemp\\quchongtap_original002.csv", encoding='gbk')