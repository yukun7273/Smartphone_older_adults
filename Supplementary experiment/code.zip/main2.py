# 所有被试实验数据合并
import pandas as pd
import os
TDpath = ["tap_original","tap_adjust","drag_original","drag_adjust"]
for i in TDpath:
    pwd = "data2\\" + i
    df_list = []
    for path, dirs, files in os.walk(pwd):
        # print(files)
        # print(path)
        # print(dirs)
        for file in files:
            file_path = os.path.join(path, file)
            # print(file_path)
            df = pd.read_csv(file_path)
            df_list.append(df)
    # print(df_list)
    result = pd.concat(df_list)
    print(result)
    result.to_csv(i + '.csv', index=False)