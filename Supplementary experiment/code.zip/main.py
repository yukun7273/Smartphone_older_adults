
# 对实验数据四种实验数据进行提取

import pandas as pd
import os
import re
path1 = '.data2'
files = os.listdir('data')

# 将tap0 的数据提取出来  调整前
for file in files:
    f = open("data\\" + file, "r")   #设置文件对象
    data = f.readlines()  # 直接将文件中按行读到list
    f.close()             # 关闭文件
    # print(data[0])
    res = []
    for i in data:
        a = re.findall(r"tap", i)
        if a:
            res.append(i)
    # print(res)

    res2 = []
    for j in res:
        d = [x for x in j.replace('-', '--').strip('tap').strip('\n').split(',')]
        res2.append(d)

    save = pd.DataFrame(index = None, data=list(res2), columns=['index', 'MT', 'd']) #columns列名，index索引名，data数据
    filename = "sucject" + file.strip('.txt')
    # print(filename)
    save.to_csv("data2\\tap_original\\" + filename + '.csv',  encoding='utf-8', index=False)

# 将tap3 的数据提取出来   调整后
for file in files:
    f = open("data\\" + file, "r")   #设置文件对象
    data = f.readlines()  # 直接将文件中按行读到list
    f.close()             # 关闭文件
    # print(data[0])
    res = []
    for i in data:
        a = re.findall(r"-", i)
        if a:
            res.append(i)
    print(res)
    print(len(res))

    res2 = []
    for j in res:
        # d = re.findall(r"tap", j)
        # res.append(d)
        if j[0] != 't':
            res2.append(j)
    print(res2)
    print(len(res2))

    res3=[]
    for j in res2:
        d = [x for x in j.replace('-', '--').strip('\n').split(',')]
        res3.append(d)

    save = pd.DataFrame(index=None, data=list(res3), columns=['index', 'MT', 'd'])  # columns列名，index索引名，data数据
    filename = "sucject" + file.strip('.txt')
    # print(filename)
    save.to_csv("data2\\tap_adjust\\" + filename + '.csv', index=False)



# 将drag1提取出来   调整前
for file in files:
    f = open("data\\" + file, "r")   #设置文件对象
    data = f.readlines()  # 直接将文件中按行读到list
    f.close()             # 关闭文件
    # print(data[0])
    res = []
    for i in data:
        a = re.findall(r"drag1", i)
        if a:
            res.append(i)
    # print(res)

    res2=[]
    for j in res:
        d = [x for x in j.replace('-', '--').strip('\n').split(',')]
        res2.append(d)

    save = pd.DataFrame(index=None, data=list(res2), columns=['successful', 'drag', 'num[i]','x1', 'y1', 'z1', 'totaltime', 'offset'])  # columns列名，index索引名，data数据
    filename = "sucject" + file.strip('.txt')
    # print(filename)
    # names = ["successful", "drag", "num[i]", "x1", "y1", "z1", "totaltime", "offset"]
    save.to_csv("data2\\drag_original\\" + filename + '.csv', index=False)


# 将drag3提取出  调整后
for file in files:
    f = open("data\\" + file, "r")   #设置文件对象
    data = f.readlines()  # 直接将文件中按行读到list
    f.close()             # 关闭文件
    # print(data[0])
    res = []
    for i in data:
        a = re.findall(r"drag3", i)
        if a:
            res.append(i)
    # print(res)

    res2=[]
    for j in res:
        d = [x for x in j.replace('-', '--').strip('\n').split(',')]
        res2.append(d)

    save = pd.DataFrame(index=None, data=list(res2), columns=['successful', 'drag', 'num[i]','x1', 'y1', 'z1', 'totaltime', 'offset'])  # columns列名，index索引名，data数据
    filename = "sucject" + file.strip('.txt')
    # print(filename)
    # names = ["successful", "drag", "num[i]", "x1", "y1", "z1", "totaltime", "offset"]
    save.to_csv("data2\\drag_adjust\\" + filename + '.csv', index=False)



# 所有被试实验数据合并
